<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (isset($data['image'])) {
        $image = $data['image'];
        $image = str_replace('data:image/png;base64,', '', $image);
        $image = str_replace(' ', '+', $image);
        $imageData = base64_decode($image);

        $fileName = 'uploads/' . uniqid() . '.png';
        if (!file_exists('uploads')) {
            mkdir('uploads', 0777, true);
        }

        file_put_contents($fileName, $imageData);
        echo "Image uploaded successfully.";
    } else {
        echo "No image data found.";
    }
} else {
    echo "Invalid request.";
}
?>
